const btn1 = document.querySelector("#button1");
if (btn1) {
  btn1.addEventListener("click", () => {
    location.href = "careerpath.html";
  





  });
}


